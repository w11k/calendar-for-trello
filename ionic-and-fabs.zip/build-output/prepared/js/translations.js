angular.module('app.translations', []);

angular.module('app.translations').config(['$translateProvider', function ($translateProvider) {

}]);
