'use strict';
angular.module('starter.dash', []);


angular.module('starter').config(function($stateProvider) {

    $stateProvider
        .state('tab.dash', {
            url: '/dash',
            views: {
                'menuContent': {
                    templateUrl: 'route/dash/dash.html',
                    controller: 'DashCtrl'
                }
            },
            resolve:{
                'authService':function(authService){
                    return authService.async();
                }
        }});
});




angular.module('starter').run(function() {});

angular.module('starter.dash').controller('DashCtrl', function($scope,authService, $location) {

$scope.login = authService;
    if (authService === true){
        $location.path("tab/month/")
    }

});